/*
Copyright (C) 2016- The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file COPYING for details.
*/

struct category *makeflow_category_lookup_or_create(const struct dag *d, const char *name);
