#! /bin/sh

sleep 1
echo Hello $1 > my.output
