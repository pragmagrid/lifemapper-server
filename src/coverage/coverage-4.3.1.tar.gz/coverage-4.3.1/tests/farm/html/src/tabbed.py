# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://bitbucket.org/ned/coveragepy/src/default/NOTICE.txt

# This file should have tabs.
x = 1
if x:
	a = "Tabbed"				# Aligned comments
	if x:					# look nice
		b = "No spaces"			# when they
	c = "Done"				# line up.
