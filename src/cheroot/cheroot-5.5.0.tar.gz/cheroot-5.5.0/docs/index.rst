Welcome to skeleton documentation!
========================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: skeleton
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

