See `Contributing <http://docs.cherrypy.org/en/latest/contribute.html>`_ in the docs.
