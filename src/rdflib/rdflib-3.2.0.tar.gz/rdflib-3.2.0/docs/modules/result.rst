.. rdflib.query.result: Result

======
Result
======
.. automodule:: rdflib.query
.. :noindex:
.. autoclass:: rdflib.query.Result
    :members:

