.. rdflib.serializer: Serializer

===========
Serializer
===========

.. automodule:: rdflib.serializer
.. :noindex:
.. autoclass:: rdflib.serializer.Serializer
   :members:


