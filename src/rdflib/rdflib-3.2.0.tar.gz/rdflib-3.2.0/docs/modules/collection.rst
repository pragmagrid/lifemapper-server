.. _others: Other modules


=============
Collection
=============

.. automodule:: rdflib.collection
.. :noindex:
.. autoclass:: rdflib.collection.Collection
    :members:
