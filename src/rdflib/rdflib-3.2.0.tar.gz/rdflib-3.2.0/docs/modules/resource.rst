.. _resource:

Resource
--------
.. automodule:: rdflib.resource
.. :noindex:

