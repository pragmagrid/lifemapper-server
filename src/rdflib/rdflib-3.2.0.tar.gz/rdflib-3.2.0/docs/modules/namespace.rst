.. _rdflib.namespace: Namespace utils

=========
Namespace
=========

.. automodule:: rdflib.namespace
    :members:

.. autoclass:: rdflib.namespace.NamespaceManager
    :members:

.. autoclass:: rdflib.namespace.Namespace
    :members:

.. autofunction:: rdflib.namespace.split_uri
