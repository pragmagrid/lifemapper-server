.. _rdflib.statement: Other modules

=========
Statement
=========

.. currentmodule:: rdflib.term
.. :noindex:
.. autoclass:: rdflib.term.Statement
.. automethod:: rdflib.term.Statement.__new__
.. automethod:: rdflib.term.Statement.__reduce__


