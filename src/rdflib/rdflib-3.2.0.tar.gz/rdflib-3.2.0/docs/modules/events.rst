.. _rdflib.events: Event registration

======
Events
======
.. automodule:: rdflib.events
.. :noindex:
.. autoclass:: rdflib.events.Event
    :members:
.. autoclass:: rdflib.events.Dispatcher
    :members:

