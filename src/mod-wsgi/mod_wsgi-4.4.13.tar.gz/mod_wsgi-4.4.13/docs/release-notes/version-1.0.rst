===========
Version 1.0
===========

Version 1.0 of mod_wsgi can be obtained from:

  http://modwsgi.googlecode.com/files/mod_wsgi-1.0.tar.gz
