1.6
===

Adopt ``irc.schedule`` as ``tempora.schedule``.

1.5
===

Adopt ``jaraco.timing`` as ``tempora.timing``.

Automatic deployment with Travis-CI.

1.4
===

Moved to Github.

Improved test support on Python 2.

1.3
===

Added divide_timedelta from ``svg.charts``.
Added date_range from ``svg.charts``.
