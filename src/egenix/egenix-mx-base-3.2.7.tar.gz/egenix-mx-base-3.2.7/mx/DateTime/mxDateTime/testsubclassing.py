import mxDateTime

class D(mxDateTime.DateTimeType):

    def test(self):
        print '.test:', self.absdate

